import java.io.*;

public class UserFileSystem {
    
    private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private static String fileName = "user_data.txt";

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            displayMenu();
            try {
                String choice = reader.readLine().toUpperCase();
                switch (choice) {
                    case "C":
                        createFile();
                        break;
                    case "W":
                        writeDataToFile();
                        break;
                    case "D":
                        deleteFile();
                        break;
                    case "V":
                        viewFileContents();
                        break;
                    case "E":
                        exitSystem();
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (IOException e) {
                System.out.println("Error reading input: " + e.getMessage());
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nUser File System Menu");
        System.out.println("C - Create File");
        System.out.println("W - Write Data to File");
        System.out.println("D - Delete File");
        System.out.println("V - View File Contents");
        System.out.println("E - Exit System");
        System.out.print("Select a process: ");
    }

    private static void createFile() {
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created successfully: " + fileName);
            } else {
                System.out.println("File already exists in the directory: " + fileName);
            }
        } catch (IOException e) {
            System.out.println("An unexpected error has occurred: " + e.getMessage());
        }
    }

    private static void writeDataToFile() {
        try {

            System.out.print("Enter User ID: ");
            String id = reader.readLine();
            System.out.print("Enter Full Name: ");
            String name = reader.readLine();
            System.out.print("Enter Age: ");
            int age = Integer.parseInt(reader.readLine());
            System.out.print("Enter Email Address: ");
            String email = reader.readLine();
            System.out.print("Enter Contact Number: ");
            String contactNo = reader.readLine();

            String data = String.format("ID: %s\nName: %s\nAge: %d\nEmail: %s\nContact No: %s\n\n",
                    id, name, age, email, contactNo);

            FileWriter fileWriter = new FileWriter(fileName, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(data);
            bufferedWriter.close();

            System.out.println("Data written to file successfully.");
        } catch (IOException e) {
            System.out.println("Error writing data to file: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Invalid age format.");
        }
    }

    private static void deleteFile() {
        File file = new File(fileName);
        if (file.exists()) {
            if (file.delete()) {
                System.out.println("File deleted successfully.");
            } else {
                System.out.println("Failed to delete the file.");
            }
        } else {
            System.out.println("Unexpected error found in the deletion of the file.");
        }
    }

    private static void viewFileContents() {
        File file = new File(fileName);
        if (file.exists()) {
            try (BufferedReader fileReader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = fileReader.readLine()) != null) {
                    System.out.println(line);
                }
            } catch (IOException e) {
                System.out.println("Error reading file: " + e.getMessage());
            }
        } else {
            System.out.println("Unexpected error occurred.");
        }
    }

    private static void exitSystem() {
        System.out.println("Exiting the system. Goodbye!");
        System.exit(0);
    }
}

