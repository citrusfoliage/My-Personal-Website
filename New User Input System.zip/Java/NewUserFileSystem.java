    import java.io.*;
    import java.util.*;

    public class NewUserFileSystem {
        
        private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        private static String fileName = "user_data.txt";
        private static Map<String, User> userRecords = new HashMap<>();

        public static void main(String[] args) {
            boolean exit = false;
            while (!exit) {
                displayMenu();
                try {
                    String choice = reader.readLine().toUpperCase();
                    switch (choice) {
                        case "C":
                            createFile();
                            break;
                        case "W":
                            writeDataToFile();
                            break;
                        case "S":
                            searchRecordByID();
                            break;
                        case "U":
                            updateRecordByID();
                            break;
                        case "D":
                            deleteRecordByID();
                            break;
                        case "V":
                            viewFileContents();
                            break;
                        case "E":
                            exitSystem();
                            exit = true;
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                } catch (IOException e) {
                    System.out.println("Error reading input: " + e.getMessage());
                }
            }
        }

        private static void displayMenu() {
            System.out.println("\nUser File System Menu");
            System.out.println("C - Create File");
            System.out.println("W - Write Data to File");
            System.out.println("S - Search Record by ID");
            System.out.println("U - Update Record by ID");
            System.out.println("D - Delete Record by ID");
            System.out.println("V - View File Contents");
            System.out.println("E - Exit System");
            System.out.print("Select a process: ");
        }

        private static void createFile() {
            try {
                File file = new File(fileName);
                if (file.createNewFile()) {
                    System.out.println("File created successfully: " + fileName);
                } else {
                    System.out.println("File already exists in the directory: " + fileName);
                }
            } catch (IOException e) {
                System.out.println("An unexpected error has occurred: " + e.getMessage());
            }
        }

        private static void writeDataToFile() {
            try {
                System.out.print("Enter User ID: ");
                String id = reader.readLine();
                System.out.print("Enter Full Name: ");
                String name = reader.readLine();
                System.out.print("Enter Age: ");
                int age = Integer.parseInt(reader.readLine());
                System.out.print("Enter Email Address: ");
                String email = reader.readLine();
                System.out.print("Enter Contact Number: ");
                String contactNo = reader.readLine();

                User newUser = new User(id, name, age, email, contactNo);
                userRecords.put(id, newUser);

                String data = String.format("ID: %s\nName: %s\nAge: %d\nEmail: %s\nContact No: %s\n\n",
                        id, name, age, email, contactNo);

                FileWriter fileWriter = new FileWriter(fileName, true);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                bufferedWriter.write(data);
                bufferedWriter.close();

                System.out.println("Data written to file successfully.");
            } catch (IOException e) {
                System.out.println("Error writing data to file: " + e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Invalid age format.");
            }
        }

        private static void searchRecordByID() {
            try {
                System.out.print("Enter User ID to search: ");
                String id = reader.readLine();
                if (userRecords.containsKey(id)) {
                    User user = userRecords.get(id);
                    System.out.println(user);
                } else {
                    System.out.println("No record found with ID: " + id);
                }
            } catch (IOException e) {
                System.out.println("Error reading input: " + e.getMessage());
            }
        }

        private static void updateRecordByID() {
            try {
                System.out.print("Enter User ID to update: ");
                String id = reader.readLine();
                if (userRecords.containsKey(id)) {
                    User user = userRecords.get(id);
                    System.out.print("Enter new Full Name (current: " + user.getFullName() + "): ");
                    String name = reader.readLine();
                    System.out.print("Enter new Age (current: " + user.getAge() + "): ");
                    int age = Integer.parseInt(reader.readLine());
                    System.out.print("Enter new Email Address (current: " + user.getEmail() + "): ");
                    String email = reader.readLine();
                    System.out.print("Enter new Contact Number (current: " + user.getContactNo() + "): ");
                    String contactNo = reader.readLine();

                    user.setFullName(name);
                    user.setAge(age);
                    user.setEmail(email);
                    user.setContactNo(contactNo);

                    System.out.println("User record updated successfully.");
                } else {
                    System.out.println("No record found with ID: " + id);
                }
            } catch (IOException e) {
                System.out.println("Error reading input: " + e.getMessage());
            }
        }

        private static void deleteRecordByID() {
            try {
                System.out.print("Enter User ID to delete: ");
                String id = reader.readLine();
                if (userRecords.containsKey(id)) {
                    userRecords.remove(id);
                    System.out.println("Record with ID " + id + " deleted.");
                } else {
                    System.out.println("No record found with ID: " + id);
                }
            } catch (IOException e) {
                System.out.println("Error reading input: " + e.getMessage());
            }
        }

        private static void viewFileContents() {
            File file = new File(fileName);
            if (file.exists()) {
                try (BufferedReader fileReader = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = fileReader.readLine()) != null) {
                        System.out.println(line);
                    }
                } catch (IOException e) {
                    System.out.println("Error reading file: " + e.getMessage());
                }
            } else {
                System.out.println("File does not exist.");
            }
        }

        private static void exitSystem() {
            System.out.println("Exiting the system. Goodbye!");
            System.exit(0);
        }

        static class User {
            private String id;
            private String fullName;
            private int age;
            private String email;
            private String contactNo;

            public User(String id, String fullName, int age, String email, String contactNo) {
                this.id = id;
                this.fullName = fullName;
                this.age = age;
                this.email = email;
                this.contactNo = contactNo;
            }

            public String getId() {
                return id;
            }

            public String getFullName() {
                return fullName;
            }

            public void setFullName(String fullName) {
                this.fullName = fullName;
            }

            public int getAge() {
                return age;
            }

            public void setAge(int age) {
                this.age = age;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getContactNo() {
                return contactNo;
            }

            public void setContactNo(String contactNo) {
                this.contactNo = contactNo;
            }

            @Override
            public String toString() {
                return String.format("ID: %s\nName: %s\nAge: %d\nEmail: %s\nContact No: %s", id, fullName, age, email, contactNo);
            }
        }
    }
