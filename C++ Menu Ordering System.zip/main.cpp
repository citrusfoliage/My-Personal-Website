#include <iostream>
#include "menu.h"
#include "meal.h"
#include "drinks.h"
#include "dessert.h"
#include "payment.h"

using namespace std;

int main() {
    Menu();
    
    char order;
    string meal, drinks, dessert;
    double total_amt = 0.0;
    double meal_order_total = 0.0, drinks_order_total = 0.0, dessert_order_total = 0.0;
    int meal_qty = 0, drinks_qty = 0, dessert_qty = 0;

    cout << "Choose Order: ";
    cin >> order;

    while (order != 'D') {
        switch (order) {
            case 'A':
                Meal(total_amt, meal, meal_qty, meal_order_total);
                break;
            case 'B':
                Drinks(total_amt, drinks, drinks_qty, drinks_order_total);
                break;
            case 'C':
                Dessert(total_amt, dessert, dessert_qty, dessert_order_total);
                break;
            default:
                cout << "Invalid choice!" << endl;
        }
        Menu();
        cout << "Choose Order: ";
        cin >> order;
    }

    cout << "Your orders are: " << endl;
    cout << "Meal:\t\t" << meal << "\t\t\t\t\t\t" << meal_qty << "\t\t\t" << "P " << meal_order_total << endl;
    cout << "Drinks:\t\t" << drinks << "\t\t\t\t\t\t\t" << drinks_qty << "\t\t\t" << "P " << drinks_order_total << endl;
    cout << "Dessert:\t" << dessert << "\t\t\t\t\t\t\t" << dessert_qty << "\t\t\t" << "P " << dessert_order_total << endl;

    Payment(total_amt);
    
    return 0;
}
