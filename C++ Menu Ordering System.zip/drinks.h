#ifndef DRINKS_H
#define DRINKS_H

#include <string>

void Drinks(double &total_amt, std::string &drinks, int &drinks_order_qty, double &drinks_order_total);

#endif
