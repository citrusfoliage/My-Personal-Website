#ifndef MEAL_H
#define MEAL_H

#include <string>

void Meal(double &total_amt, std::string &meal, int &meal_order_qty, double &meal_order_total);

#endif
