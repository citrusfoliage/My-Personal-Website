#include <iostream>
#include "menu.h"

using namespace std;

void Menu() {
    cout << "- MENU -" << endl;
    cout << "[A] Meal" << endl;
    cout << "[B] Drinks" << endl;
    cout << "[C] Dessert" << endl;
    cout << "[D] Payment" << endl;
}
