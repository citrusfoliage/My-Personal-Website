#include <iostream>
#include "drinks.h"

using namespace std;

void Drinks(double &total_amt, string &drinks, int &drinks_order_qty, double &drinks_order_total) {
    char drinks_choice;

    cout << "- DRINKS LIST -" << endl;
    cout << "[A] Drink 1\t\tCoffee\t\t\tP 25.00" << endl;
    cout << "[B] Drink 2\t\tIced Tea\t\tP 25.00" << endl;
    cout << "[C] Drink 3\t\tSoft Drinks\t\tP 20.00" << endl;
    cout << "Choose Order: ";
    cin >> drinks_choice;

    cout << "Enter Quantity: ";
    cin >> drinks_order_qty;

    switch (drinks_choice) {
        case 'A':
            drinks = "Drink 1\t\t\tCoffee";
            drinks_order_total = 25 * drinks_order_qty;
            total_amt += drinks_order_total;
            break;
        case 'B':
            drinks = "Drink 2\t\t\tIced Tea";
            drinks_order_total = 25 * drinks_order_qty;
            total_amt += drinks_order_total;
            break;
        case 'C':
            drinks = "Drink 3\t\t\tSoft Drinks";
            drinks_order_total = 20 * drinks_order_qty;
            total_amt += drinks_order_total;
            break;
        default:
            cout << "Your choice of drink is not in the menu!" << endl;
    }
}
