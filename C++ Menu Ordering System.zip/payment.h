#ifndef PAYMENT_H
#define PAYMENT_H

void Payment(double total_amt);

#endif
