#ifndef DESSERT_H
#define DESSERT_H

#include <string>

void Dessert(double &total_amt, std::string &dessert, int &dessert_order_qty, double &dessert_order_total);

#endif
