#include <iostream>
#include "dessert.h"

using namespace std;

void Dessert(double &total_amt, string &dessert, int &dessert_order_qty, double &dessert_order_total) {
    char dessert_choice;

    cout << "- DESSERT LIST -" << endl;
    cout << "[A] Dessert 1\t\tIce Cream\t\t\tP 15.00" << endl;
    cout << "[B] Dessert 2\t\tCake\t\t\t\tP 50.00" << endl;
    cout << "[C] Dessert 3\t\tCoffee Jelly\t\t\tP 25.55" << endl;
    cout << "Choose Order: ";
    cin >> dessert_choice;

    cout << "Enter Quantity: ";
    cin >> dessert_order_qty;

    switch (dessert_choice) {
        case 'A':
            dessert = "Dessert 1\t\tIce Cream";
            dessert_order_total = 15 * dessert_order_qty;
            total_amt += dessert_order_total;
            break;
        case 'B':
            dessert = "Dessert 2\t\tCake";
            dessert_order_total = 50 * dessert_order_qty;
            total_amt += dessert_order_total;
            break;
        case 'C':
            dessert = "Dessert 3\t\tCoffee Jelly";
            dessert_order_total = 25.55 * dessert_order_qty;
            total_amt += dessert_order_total;
            break;
        default:
            cout << "Your choice of dessert is not in the menu!" << endl;
    }
}
