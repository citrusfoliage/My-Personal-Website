#include <iostream>
#include "payment.h"

using namespace std;

void Payment(double total_amt) {
    double payment_amt, change;

    cout << "Total Amount: P " << total_amt << endl;
    cout << "Payment Amount: P ";
    cin >> payment_amt;

    if (payment_amt < total_amt) {
        cout << "Your payment is insufficient!" << endl;
    } else {
        change = payment_amt - total_amt;
        cout << "Change: P " << change << endl;
    }
}
