#include <iostream>
#include "meal.h"

using namespace std;

void Meal(double &total_amt, string &meal, int &meal_order_qty, double &meal_order_total) {
    char meal_choice;

    cout << "- MEAL LIST -" << endl;
    cout << "[A] Meal 1\t\tBurger and Fries\t\t\tP 75.00" << endl;
    cout << "[B] Meal 2\t\tSpaghetti and Clubhouse\t\t\tP 100.00" << endl;
    cout << "[C] Meal 3\t\tCarbonara and Chicken\t\t\tP 125.00" << endl;
    cout << "Choose Order: ";
    cin >> meal_choice;

    cout << "Enter Quantity: ";
    cin >> meal_order_qty;

    switch (meal_choice) {
        case 'A':
            meal = "Meal 1\t\t\tBurger and Fries";
            meal_order_total = 75 * meal_order_qty;
            total_amt += meal_order_total;
            break;
        case 'B':
            meal = "Meal 2\t\t\tSpaghetti and Clubhouse";
            meal_order_total = 100 * meal_order_qty;
            total_amt += meal_order_total;
            break;
        case 'C':
            meal = "Meal 3\t\t\tCarbonara and Chicken";
            meal_order_total = 125 * meal_order_qty;
            total_amt += meal_order_total;
            break;
        default:
            cout << "Your choice of meal is not in the menu!" << endl;
    }
}
